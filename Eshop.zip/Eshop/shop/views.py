from math import ceil
from django.shortcuts import render, redirect
from django.db.models import Q
from django.http import JsonResponse, HttpResponseRedirect
# Create your views here.
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from shop.forms import Product_Upadate_Form
from shop.models import Product, Category, Sub_Category,Customer,Cart,OrderMaster,OrderDetail,Seller,Seller_Shope_Category,Order_Status,Staf
from rest_framework.renderers import JSONRenderer
import json


def index(request):
    if request.session.has_key('mobile'):
        mobile=request.session["mobile"]
        category = Category.objects.all()
        totalitem=0
        totalitem=len(Cart.objects.filter(mobile=mobile))
        #print(totalitem)
        return render(request, 'shop/test.html', {'totalitem':totalitem,'categorys': category, 'user':request.session["mobile"]})
    else:
        return redirect('login')





def subcat(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        subcat = Sub_Category.objects.values().filter(category_id=prod_id)
        sub_category =list(subcat)
        #print(sub_category)
        return JsonResponse({'sub_category':sub_category})

#@csrf_exempt
def product(request):
    if request.method == 'GET':
        id = request.GET['subid']
        product = Product.objects.values().filter(sub_category_id=id)
        allproduct =list(product)
        #print(allproduct)
        return JsonResponse({'status':1,'allproduct':allproduct})
    else:
        return JsonResponse({'status':0})

def login(request):
    if request.method == 'POST':
        s=Customer.objects.filter(mobile=request.POST["mb"])
        if s:
            request.session['mobile']=request.POST["mb"]
            return redirect('ShopHome')
        else:
            return redirect('reg')
    return render(request,'shop/login.html')

def logout(request):
    if request.method == 'POST':
        del request.session['mobile']
        return redirect('login')
    else:
        return redirect('login')

def reg(request):
    if request.method=="POST":
        cus=Customer(mobile=request.POST["mb"],name=request.POST["name"],addrress=request.POST["address"])
        cus.save()
        request.session['mobile']=request.POST["mb"]
        return redirect('ShopHome')
    return render(request,'shop/reg.html')

@csrf_exempt
def add_to_cart(request):
    product_id=request.POST['prid']
    productpr = request.POST['prsid']
    product_name = request.POST['pr_name']
    #print(product_name)
    mobile = request.session["mobile"]
    product = Product.objects.get(id=product_id)
    item_already_in_cart1 = Cart.objects.filter(Q(product=product) & Q(mobile =mobile)).exists()
    if item_already_in_cart1 == False:
        cart=Cart(mobile =mobile, product =product, price=productpr,product_name=product_name)
        cart.save()

        totalitem=0
        totalitem=len(Cart.objects.filter(mobile=mobile))
        print(totalitem)
        return JsonResponse({'status': 1,'totalitem':totalitem})
    else:
        totalitem = 0
        totalitem = len(Cart.objects.filter(mobile=mobile))
        print(totalitem)
        return JsonResponse({'status': 0,'totalitem':totalitem})

def show_cart(request):
    if request.session.has_key('mobile'):
        mobile = request.session["mobile"]
        cart=Cart.objects.filter(mobile=mobile)
        #print(cart.qty)
        amount=0
        shipping_amount=20
        total_amount=0.0
        cart_product=[p for p in cart]
        #print(cart_product)
        if cart_product:
            for p in cart_product:
                tempamount=(p.qty * p.product.price)
                amount += tempamount
                totalamount =amount + shipping_amount
                #print(amount)
            return render(request,'shop/addtocart.html',{'tempamount':tempamount, 'amount':amount,'totalamount':totalamount, 'carts':cart ,'user':request.session["mobile"]})
        else:
            return render(request,'shop/empty.html')

def plus_cart(request):
    if request.method=="GET":
        cprod_id=request.GET['cprod_id']
        mobile = request.session["mobile"]
        c = Cart.objects.get(Q(product=cprod_id) & Q(mobile=mobile))
        c.qty+=1
        c.totalprice=c.qty*c.price
        print(c.totalprice)
        c.save()
        amount = 0
        shipping_amount=20
        cart = Cart.objects.filter(mobile=mobile)
        cart_product = [p for p in cart]
        for p in cart_product:
            tempamount = (p.qty * p.product.price)
            amount += tempamount
            totalamount = amount + shipping_amount
            tprice=p.totalprice
        data={
            'qty':c.qty,
            'amount':amount,
            'totalamount':totalamount,
            'tprice':tprice,
        }
        return JsonResponse(data)

def minus_cart(request):
    if request.method=="GET":
        cprod_id=request.GET['cprod_id']
        mobile = request.session["mobile"]
        c = Cart.objects.get(Q(product=cprod_id) & Q(mobile=mobile))
        c.qty-=1
        c.totalprice = c.qty * c.price
        c.save()
        amount = 0
        shipping_amount=20
        cart = Cart.objects.filter(mobile=mobile)
        cart_product = [p for p in cart]
        for p in cart_product:
            tempamount = (p.qty * p.product.price)
            amount += tempamount
            tprice = p.totalprice

        data={
            'qty':c.qty,
            'amount':amount,
            'totalamount':amount + shipping_amount,
            'tprice': tprice,
        }
        return JsonResponse(data)

def remove_cart(request):
    if request.method=="GET":
        cprod_id=request.GET['cprod_id']
        mobile = request.session["mobile"]
        c = Cart.objects.get(Q(product=cprod_id) & Q(mobile=mobile))
        c.delete()
        amount = 0
        shipping_amount=20
        cart = Cart.objects.filter(mobile=mobile)
        cart_product = [p for p in cart]
        for p in cart_product:
            tempamount = (p.qty * p.product.price)
            amount += tempamount

        data={

            'amount':amount,
            'totalamount':amount + shipping_amount
        }
        #print(data)
        return JsonResponse(data)


def payment_done(request):
    mobile = request.session["mobile"]
    customer = Customer.objects.filter(mobile=mobile)
    for cu in customer:
        name=cu.name
        add = cu.addrress
        cid = cu.id
        cart_product = Cart.objects.filter(mobile=mobile)
        cart_items = Cart.objects.filter(mobile=mobile)
        amount = 0
        shipping_amount = 20
        totalamount = 0
        if cart_product:
            for p in cart_product:
                pid=p.product_id
                tempamount = (p.qty * p.product.price)
                amount += tempamount
            totalamount = amount + shipping_amount
        ordermaster=OrderMaster(name=name,addrress=add,total_price=totalamount,customer=cid,mobile=mobile)
        ordermaster.save()
        cart_product = Cart.objects.filter(mobile=mobile)
        for p in cart_product:
            pid=p.product_id
            qty=p.qty
            prc=p.price
            pname = p.product_name
            totalprice=(p.qty*p.price)
            seller_name = p.product.seller_name
            omid=OrderMaster.objects.filter(mobile=mobile)
            for od in omid:
                idnew=od.id
            orderdetails=OrderDetail(totalprice=totalprice,seller_name=seller_name,product_name=pname,mobile=mobile,product=pid,qty=qty,price=prc,orderfilter=idnew)
            orderdetails.save()
            cart_items.delete()
        return render(request, 'shop/order_success.html')

def order(request):
    order = OrderMaster.objects.all()
    return render(request, 'shop/order.html',{'order':order})


def order_details(request,order_id):
    if request.session.has_key('staff_mobile'):
        order = OrderDetail.objects.filter(orderfilter=order_id)
        order_items = OrderDetail.objects.filter(orderfilter=order_id)
        order_status = Order_Status.objects.all()
        order_curant_status = OrderMaster.objects.filter(pk=order_id)
        print(order_curant_status)
        amount = 0
        shipping_amount = 20
        totalamount = 0
        if order_items:
            for p in order_items:
                tempamount = (p.qty * p.price)
                amount += tempamount
                mobile = p.mobile
                print(tempamount)
            totalamount = amount + shipping_amount
            customer=Customer.objects.filter(mobile=mobile)
        return render(request, 'shop/order_details.html',{'order_curant_status':order_curant_status,'order_id':order_id,'order_status':order_status,'customer':customer,'order':order,'amount':amount,'totalamount':totalamount})
    else:
        return redirect('staff_login')

@csrf_exempt
def update_order_status(request):
    if request.method == 'POST':
        order_id = request.POST['order_id']
        status = request.POST['status']
        order_items=OrderMaster.objects.filter(pk=order_id)
        for o in order_items:
            mobile=o.mobile
            name=o.name
            addrress=o.addrress
            total_price=o.total_price
            customer=o.customer
            print(total_price)
            order=OrderMaster(id=order_id,mobile=mobile,name=name,addrress=addrress,total_price=total_price,customer=customer,status=status)
            order.save()
        return JsonResponse({'status': 1, })
    else:
        return JsonResponse({'status': 0, })



def product_details(request,product_id):
    if request.session.has_key('mobile'):
        mobile=request.session["mobile"]
        product = Product.objects.filter(id=product_id)
        for p in product:
            subid=p.sub_category_id
        rlproduct = Product.objects.filter(sub_category_id=subid)
        rlcategory = Sub_Category.objects.filter(id=subid)
        for rc in rlcategory:
            rcid=rc.category_id
        rlcat = Sub_Category.objects.filter(category_id=rcid)
        #print(rlcat)
        category = Category.objects.all()
        return render(request, 'shop/product_details.html',{'related_category':rlcat,'product':product,'rlproduct':rlproduct,'categorys':category})
    else:
        return redirect('login')


@csrf_exempt
def delete_order_product(request):
    if request.method == 'POST':
        product_id = request.POST['product_id']
        product=OrderDetail.objects.get(pk=product_id)
        product.delete()
        return JsonResponse({'status': 1,})
    return render(request, 'seller/add_product.html')


def subcat_details(request):
    if request.method == 'GET':
        id = request.GET['subid']
        product = Product.objects.values().filter(sub_category_id=id)
        allproduct =list(product)
        #print(allproduct)
        return JsonResponse({'status':1,'allproduct':allproduct})
    else:
        return JsonResponse({'status':0})

def sellerlogin(request):
    if request.method == 'POST':
        s=Seller.objects.filter(seller_mobile=request.POST["mb"],pin=request.POST["pin"] )
        if s:
            request.session['mobile']=request.POST["mb"]
            seller =Seller.objects.filter(seller_mobile=request.POST["mb"])
            for slerid in seller :
                s_id=slerid.id
                s_name = slerid.seller_name
                s_mobile = slerid.seller_mobile
                shope_name = slerid.shope_name
                request.session['seller_id']=s_id
                request.session['seller_name'] = s_name
                request.session['seller_mobile'] = s_mobile
                request.session['shop_name'] = shope_name
                #print(s_name)
            return redirect('add_product')
        else:
            return redirect('sellerlogin')
    return render(request,'seller/seller_login.html')


def select_category(request):
    category = Category.objects.all()
    return render(request, 'seller/shope_category.html',{'category':category})

@csrf_exempt
def add_shop_category(request):
    shop_category_id = request.POST['shop_category_id']
    mobile = request.session["mobile"]
    #print(shop_category_id)
    seller=Seller.objects.filter(seller_mobile=mobile)
    for slr in seller:
        seller_id=slr.id
        #print(seller_id)
        shope_category_already_in = Seller_Shope_Category.objects.filter(Q(seller_id=seller_id) & Q(category_id=shop_category_id)).exists()
        if shope_category_already_in == False:
            shope_category=Seller_Shope_Category(seller_id=seller_id,category_id=shop_category_id)
            shope_category.save()
            return JsonResponse({'status': 1})
        else:
            return JsonResponse({'status': 0})


def add_product(request):
    if request.session.has_key('mobile'):
        mobile=request.session["mobile"]
        seller_id = request.session["seller_id"]
        shop_name=request.session["shop_name"]
        print(shop_name)
        cat_id=Seller_Shope_Category.objects.filter(seller_id=seller_id)
        for ctr in cat_id:
            cat_id=ctr.category_id
        category=Category.objects.filter()
        if request.method == "POST":
            sub_category_id = request.POST.get("sub_category_id")
            product_name = request.POST.get("product_name")
            desc = request.POST.get("desc")
            price = request.POST.get("price")
            image = request.FILES.get("image")
            product=Product(image=image,seller_name=shop_name,sub_category_id=sub_category_id,product_name=product_name,desc=desc,price=price,seller_id=seller_id)
            product.save()
            return redirect('my_product')
        return render(request,'seller/add_product.html',{'category':category})
    else:
        return redirect('sellerlogin')

@csrf_exempt
def add_new_product(request):
    category_id = request.POST['category_id']
    subcat = Sub_Category.objects.values().filter(category_id=category_id)
    sub_category = list(subcat)
    #print(sub_category)
    return JsonResponse({'status': 1,'sub_category':sub_category})

def my_product(request):
    if request.session.has_key('mobile'):
        seller_id = request.session["seller_id"]
        product=Product.objects.filter(seller_id=seller_id)
    return render(request,'seller/my_product.html',{'product':product})

@csrf_exempt
def delete_product(request):
    if request.method == 'POST':
        product_id = request.POST['product_id']
        product=Product.objects.get(pk=product_id)
        product.delete()
        return JsonResponse({'status': 1,})
    return render(request, 'seller/add_product.html')


def update_product(request,product_id):
    product=Product.objects.get(pk=product_id)
    if request.session.has_key('mobile'):
        mobile=request.session["mobile"]
        seller_id = request.session["seller_id"]
        shop_name=request.session["shop_name"]
        print(shop_name)
        cat_id=Seller_Shope_Category.objects.filter(seller_id=seller_id)
        for ctr in cat_id:
            cat_id=ctr.category_id
        category=Category.objects.filter()
    if request.method == "POST":
        sub_category_id = request.POST.get("sub_category_id")
        product_name = request.POST.get("product_name")
        desc = request.POST.get("desc")
        price = request.POST.get("price")
        image = request.FILES.get("image")
        product = Product(id=product_id,image=image, seller_name=shop_name, sub_category_id=sub_category_id, product_name=product_name,
                      desc=desc, price=price, seller_id=seller_id)
        product.save()

    return render(request, 'seller/update_product.html',{'product':product,'category':category})

def staff_login(request):
    if request.method == 'POST':
        s=Staf.objects.filter(mobile=request.POST["mb"],pin=request.POST["pin"] )
        if s:
            request.session['mobile']=request.POST["mb"]
            staff =Staf.objects.filter(mobile=request.POST["mb"])
            for staff in staff :
                s_id=staff.id
                s_name = staff.name
                s_mobile = staff.mobile
                request.session['staff_id']=s_id
                request.session['staff_name'] = s_name
                request.session['staff_mobile'] = s_mobile
                #print(s_name)
            return redirect('order')
        else:
            return redirect('sellerlogin')
    return render(request,'seller/staff_login.html')


def update_product_new(request,product_id):
    product=Product.objects.get(pk=product_id)
    form=Product_Upadate_Form(instance=product)
    if request.method =='POST':
        form=Product_Upadate_Form(request.POST,instance=product,)
        if form.is_valid():
            form.save()
            return redirect('my_product')
    return render(request, 'seller/update_product_new.html',{'form':form})
